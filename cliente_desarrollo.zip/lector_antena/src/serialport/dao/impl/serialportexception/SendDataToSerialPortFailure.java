package serialport.dao.impl.serialportexception;

@SuppressWarnings("serial")
public class SendDataToSerialPortFailure extends Exception {

}
