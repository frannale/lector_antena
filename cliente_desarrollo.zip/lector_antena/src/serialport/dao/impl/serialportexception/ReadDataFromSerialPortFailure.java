package serialport.dao.impl.serialportexception;

@SuppressWarnings("serial")
public class ReadDataFromSerialPortFailure extends Exception {

}
