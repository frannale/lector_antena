package serialport.dao.impl.serialportexception;

public class NoSuchSerialPort extends Exception{
	/**
     * 
     */
	private static final long serialVersionUID = 1L;

	public NoSuchSerialPort() {
	}

	@Override
	public String toString() {
		return "�˿�û�ҵ�";
	}
}
