package serialport.dao.impl.serialportexception;

public class NotASerialPort extends Exception{
	/**
     * 
     */
	private static final long serialVersionUID = 1L;

	public NotASerialPort() {
	}

	@Override
	public String toString() {
		return "";
	}
}
