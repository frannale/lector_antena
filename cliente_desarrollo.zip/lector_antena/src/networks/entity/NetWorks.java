package networks.entity;

public class NetWorks {

}
